for i in `cat ID`;do mafft $i/$i > $i.MSA ;done

